
  # UI Kit for UrbanSync

  This is a code bundle for UI Kit for UrbanSync. The original project is available at https://www.figma.com/design/InlP4H1xExJuHOUY4Cg7E9/UI-Kit-for-UrbanSync.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  